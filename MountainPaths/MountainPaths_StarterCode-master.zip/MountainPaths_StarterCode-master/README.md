# MountainPaths_StarterCode
Starter Code for Mountain Paths

1) Download files as zip
2) Unzip and rename folder as you please
3) Open folder in intelliJ
4) ...
5) Profit!
